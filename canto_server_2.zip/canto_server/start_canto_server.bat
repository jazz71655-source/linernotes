chcp 65001 > nul
@echo off
rem CANTO Local Metadata Server - Windows kidou script
rem This file wo double click suru to local server ga kidou shimasu.

cd /d "%~dp0"

echo ==================================================
echo  CANTO Local Metadata Server wo kidou shite imasu...
echo ==================================================

where python >nul 2>nul
if errorlevel 1 (
    echo ERROR: python ga mitsukarimasen.
    echo https://www.python.org/downloads/ kara install shite kudasai.
    echo Install ji ni "Add python.exe to PATH" ni check wo irete kudasai.
    pause
    exit /b 1
)

if not exist venv (
    echo Shokai setup: kasou kankyou wo sakusei shite imasu...
    python -m venv venv
)

call venv\Scripts\activate.bat

echo Hitsuyou na package wo kakunin shite imasu...
pip install -q --disable-pip-version-check -r requirements.txt

echo.
python app.py

echo.
pause
