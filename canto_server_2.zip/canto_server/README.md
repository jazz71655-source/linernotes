# CANTO Local Metadata Server

CANTO(ブラウザ音楽プレイヤー)のメタデータ・アートワークを、ブラウザの IndexedDB ではなく
**この PC 上の SQLite ファイル**に永続保存するためのローカルサーバーです。

Brave のプライベートウィンドウなど、ブラウザのストレージがセッション終了時に消える環境でも、
このサーバーが起動していればデータは `canto_meta.db` に残り続けます。

---

## 初回セットアップ

1. Python 3 がインストールされていることを確認してください。
   - 確認方法: ターミナル(Mac)またはコマンドプロンプト(Windows)で `python3 --version` または `python --version`
   - 入っていなければ https://www.python.org/downloads/ からインストール
   - **Windows の場合、インストール時に「Add python.exe to PATH」に必ずチェックを入れてください**
2. このフォルダ(`canto_server`)を MacBook Pro と ThinkPad それぞれの好きな場所に置いてください。
   - **各PCに個別に配置してください。DBファイルはPCごとに別々に作られます(共有されません)。**

## 起動方法

- **Mac**: `start_canto_server.command` をダブルクリック
  - 初回は「開発元を検証できません」と出た場合、右クリック→「開く」で許可してください
- **Windows**: `start_canto_server.bat` をダブルクリック

初回起動時のみ、自動的に仮想環境の作成とパッケージのインストールが行われます(数十秒〜1分程度)。
2回目以降はすぐに起動します。

起動すると黒い画面(ターミナル/コマンドプロンプト)が開いたままになります。
**CANTOを使い終わるまで、この画面は閉じないでください。**

正常に起動すると、以下のように表示されます。

```
==================================================
 CANTO Local Metadata Server
 DB file : /path/to/canto_server/canto_meta.db
 URL     : http://127.0.0.1:8787
 Allowed : ['https://jazz71655-source.github.io']
==================================================
```

## CANTO側の設定

ブラウザで CANTO(GitHub Pages)を開くと、自動的に `http://127.0.0.1:8787` への接続を試みます。
接続できない場合は、今まで通り IndexedDB を使った一時保存にフォールバックします(データが消えることはありません)。

## データの場所

- `canto_meta.db` … このフォルダ内に作られる SQLite ファイル。全メタデータ・アートワークが入っています。
- バックアップしたい場合は、このファイルをコピーしておくだけで大丈夫です。

## ポート番号を変更したい場合

環境変数 `PORT` で変更できます。例(Mac/ターミナル):

```
PORT=9090 ./start_canto_server.command
```

## トラブルシューティング

- 「Address already in use」と出る → 既に別のCANTOサーバーが起動中です。二重起動していないか確認してください。
- 「python3 が見つかりません」→ Python未インストール、またはPATHが通っていません。
