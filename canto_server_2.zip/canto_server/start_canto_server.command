#!/bin/bash
# CANTO Local Metadata Server - Mac起動スクリプト
# このファイルをダブルクリックすると、ローカルサーバーが起動します。

cd "$(dirname "$0")"

echo "=================================================="
echo " CANTO Local Metadata Server を起動しています..."
echo "=================================================="

# python3 の存在確認
if ! command -v python3 &> /dev/null; then
    echo "エラー: python3 が見つかりません。"
    echo "https://www.python.org/downloads/ からインストールしてください。"
    read -p "Enterキーで閉じます..."
    exit 1
fi

# 仮想環境が無ければ作成
if [ ! -d "venv" ]; then
    echo "初回セットアップ: 仮想環境を作成しています..."
    python3 -m venv venv
fi

source venv/bin/activate

echo "必要なパッケージを確認しています..."
pip install -q --disable-pip-version-check -r requirements.txt

echo ""
python3 app.py

# サーバー終了後、ウィンドウを開いたままにする(エラー確認用)
echo ""
read -p "サーバーが終了しました。Enterキーでウィンドウを閉じます..."
