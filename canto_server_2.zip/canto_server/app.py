"""
CANTO Local Metadata Server
============================
CANTO(ブラウザ音楽プレイヤー)のメタデータ・アートワークを
ブラウザのIndexedDBではなく、このPC上のSQLiteファイルに永続保存するための
ローカルAPIサーバーです。

起動方法:
  Mac    : start_canto_server.command をダブルクリック
  Windows: start_canto_server.bat をダブルクリック

起動後、http://127.0.0.1:8787 で待機します。
CANTO(ブラウザ側)は自動でこのサーバーに接続を試みます。

このサーバーは各PC(ノード)ごとに独立して動作し、DBファイル(canto_meta.db)も
起動したPCのこのフォルダ内に作られます。他のPCとは共有されません。
"""

import os
import sqlite3
import datetime
from flask import Flask, request, jsonify, g
from flask_cors import CORS

# ════════════════════════════════════════════
#  設定
# ════════════════════════════════════════════
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "canto_meta.db")
PORT = int(os.environ.get("PORT", 8787))

# CANTOをホストしているGitHub Pagesのオリジン。
# 複数の環境(本番/テスト)がある場合はカンマ区切りで環境変数 CANTO_ALLOWED_ORIGINS に追加可能。
DEFAULT_ORIGINS = [
    "https://jazz71655-source.github.io",
]
extra = os.environ.get("CANTO_ALLOWED_ORIGINS", "")
ALLOWED_ORIGINS = DEFAULT_ORIGINS + [o.strip() for o in extra.split(",") if o.strip()]

app = Flask(__name__)
CORS(app, origins=ALLOWED_ORIGINS)

# ════════════════════════════════════════════
#  DB接続
# ════════════════════════════════════════════
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS tracks (
            track_key   TEXT PRIMARY KEY,
            title       TEXT DEFAULT '',
            artist      TEXT DEFAULT '',
            album       TEXT DEFAULT '',
            year        TEXT DEFAULT '',
            genre       TEXT DEFAULT '',
            notes       TEXT DEFAULT '',
            favorite    INTEGER DEFAULT 0,
            artwork     TEXT DEFAULT '',
            updated_at  TEXT
        )
        """
    )
    conn.commit()
    conn.close()


def normalize_key(raw_key: str) -> str:
    """
    曲の紐付けキーを正規化する(ノード内のみでの比較用)。
    - 前後の空白を除去
    - 小文字化
    - 拡張子を除去(最後の '.' 以降)
    実ファイル名は一切変更しない。あくまで照合用の文字列処理。
    """
    if not raw_key:
        return ""
    s = raw_key.strip()
    if "." in s:
        s = s.rsplit(".", 1)[0]
    return s.strip().lower()


def row_to_dict(row):
    return {
        "track_key": row["track_key"],
        "title": row["title"],
        "artist": row["artist"],
        "album": row["album"],
        "year": row["year"],
        "genre": row["genre"],
        "notes": row["notes"],
        "favorite": bool(row["favorite"]),
        "artwork": row["artwork"],
        "updated_at": row["updated_at"],
    }


# ════════════════════════════════════════════
#  ルート / 生存確認
# ════════════════════════════════════════════
@app.route("/")
def index():
    return jsonify({
        "service": "CANTO Local Metadata Server",
        "status": "ok",
        "db_path": DB_PATH,
    })


@app.route("/api/ping")
def ping():
    return jsonify({"status": "ok", "time": datetime.datetime.now().isoformat()})


# ════════════════════════════════════════════
#  トラックAPI
# ════════════════════════════════════════════
@app.route("/api/tracks", methods=["GET"])
def get_all_tracks():
    """起動時の一括同期用。全曲分のメタデータを返す。"""
    db = get_db()
    rows = db.execute("SELECT * FROM tracks").fetchall()
    return jsonify([row_to_dict(r) for r in rows])


@app.route("/api/track/<path:track_key>", methods=["GET"])
def get_track(track_key):
    key = normalize_key(track_key)
    db = get_db()
    row = db.execute(
        "SELECT * FROM tracks WHERE track_key = ?", (key,)
    ).fetchone()
    if row is None:
        return jsonify({"error": "not_found"}), 404
    return jsonify(row_to_dict(row))


@app.route("/api/track", methods=["POST"])
def upsert_track():
    """
    メタデータ・アートワークの保存(新規/更新どちらも)。
    body(JSON):
      {
        "track_key": "曲を識別するキー(必須。CANTO側で生成)",
        "title": "...", "artist": "...", "album": "...",
        "year": "...", "genre": "...", "notes": "...",
        "favorite": true/false,
        "artwork": "data:image/jpeg;base64,..." (省略可)
      }
    """
    data = request.get_json(silent=True) or {}
    raw_key = data.get("track_key", "")
    key = normalize_key(raw_key)
    if not key:
        return jsonify({"error": "track_key is required"}), 400

    db = get_db()
    now = datetime.datetime.now().isoformat()
    db.execute(
        """
        INSERT INTO tracks
            (track_key, title, artist, album, year, genre, notes, favorite, artwork, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(track_key) DO UPDATE SET
            title=excluded.title,
            artist=excluded.artist,
            album=excluded.album,
            year=excluded.year,
            genre=excluded.genre,
            notes=excluded.notes,
            favorite=excluded.favorite,
            artwork=excluded.artwork,
            updated_at=excluded.updated_at
        """,
        (
            key,
            data.get("title", ""),
            data.get("artist", ""),
            data.get("album", ""),
            data.get("year", ""),
            data.get("genre", ""),
            data.get("notes", ""),
            1 if data.get("favorite") else 0,
            data.get("artwork", ""),
            now,
        ),
    )
    db.commit()
    return jsonify({"status": "saved", "track_key": key, "updated_at": now})


@app.route("/api/track/<path:track_key>", methods=["DELETE"])
def delete_track(track_key):
    key = normalize_key(track_key)
    db = get_db()
    db.execute("DELETE FROM tracks WHERE track_key = ?", (key,))
    db.commit()
    return jsonify({"status": "deleted", "track_key": key})


# ════════════════════════════════════════════
#  起動
# ════════════════════════════════════════════
if __name__ == "__main__":
    init_db()
    print("=" * 50)
    print(" CANTO Local Metadata Server")
    print(f" DB file : {DB_PATH}")
    print(f" URL     : http://127.0.0.1:{PORT}")
    print(f" Allowed : {ALLOWED_ORIGINS}")
    print(" このウィンドウは閉じずに、CANTOを使い終わるまで開いたままにしてください。")
    print("=" * 50)
    app.run(host="127.0.0.1", port=PORT, debug=False)
